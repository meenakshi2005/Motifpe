import React from "react";
import "../assets/css/style.css";
// import logo from "../assets/logo.png"; // Adjust the path if needed

const Navbar = () => {
  return (
    <header className="navbar">
      <div className="logo-section">
        {/* <img src={logo} alt="Logo" className="logo-img" /> */}
        <span className="logo-text">MotifPe</span>
      </div>

      <nav className="nav-links">
        <ul>
          <li><a href="#">Home</a></li>
          <li><a href="#">About Us</a></li>
          <li><a href="#">Contact Us</a></li>
        </ul>
      </nav>

      <button className="demo-btn">Request Demo</button>
    </header>
  );
};

export default Navbar;
