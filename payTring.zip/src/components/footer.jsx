import React from "react";

const Footer = () => {
  return (
    <footer className="bg-[#2e333a] text-white px-[5%] py-12 text-sm">
      {/* Top Section */}
      <div className="max-w-[1400px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-10">
        {/* Column 1 - Logo + Links */}
        <div>
          <img src="/logo.png" alt="MotifPe Logo" className="h-10 mb-6" />
          <h3 className="text-lg font-bold text-[#2196f3] mb-4">Useful Links</h3>
          <ul className="space-y-2 font-semibold">
            <li><a href="/" className="hover:underline">Home</a></li>
            <li><a href="/about" className="hover:underline">About Us</a></li>
            <li><a href="/contact" className="hover:underline">Contact Us</a></li>
            <li><a href="/faq" className="hover:underline">FAQ</a></li>
          </ul>
        </div>

        {/* Column 2 - Legal + More */}
        <div className="pt-12 md:pt-0">
          <ul className="space-y-2 font-semibold">
            <li><a href="/blogs" className="hover:underline">Blogs</a></li>
            <li><a href="/career" className="hover:underline">Career</a></li>
            <li><a href="/privacy-policy" className="hover:underline">Privacy Policy</a></li>
            <li><a href="/terms" className="hover:underline">Terms & Conditions</a></li>
            <li><a href="/refund" className="hover:underline">Cancellation & Refund</a></li>
          </ul>
        </div>

        {/* Column 3 - Mission */}
        <div>
          <h3 className="text-lg font-bold text-[#2196f3] mb-4">Our Mission</h3>
          <p className="text-gray-300 leading-relaxed mb-6">
            Our mission is to create an innovative financial platform that delivers seamless, secure, and smart transactions to everyone, everywhere.
          </p>
          {/* Social Icons */}
          <div className="flex gap-4">
            {/* LinkedIn */}
            <a href="#" className="hover:text-[#2196f3]">
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M4.98 3.5c0 1.38-1.12 2.5-2.49 2.5S0 4.88 0 3.5 1.12 1 2.49 1s2.49 1.12 2.49 2.5zM.5 8.5H4v12H.5v-12zm7.5 0H12v1.75h.05c.49-.93 1.68-1.91 3.45-1.91 3.69 0 4.5 2.43 4.5 5.6v6.56H16v-5.82c0-1.39-.03-3.17-1.93-3.17-1.94 0-2.24 1.51-2.24 3.06v5.93H8V8.5z"/>
              </svg>
            </a>
            {/* Email */}
            <a href="#" className="hover:text-[#2196f3]">
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M20 4H4a2 2 0 00-2 2v12a2 2 0 002 2h16a2 2 0 002-2V6a2 2 0 00-2-2zm0 2v.01L12 13 4 6.01V6h16zM4 18V8l8 5 8-5v10H4z"/>
              </svg>
            </a>
            {/* Phone */}
            <a href="#" className="hover:text-[#2196f3]">
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M6.62 10.79a15.05 15.05 0 006.59 6.59l2.2-2.2a1 1 0 011.11-.27c1.21.49 2.53.76 3.88.76a1 1 0 011 1V20a1 1 0 01-1 1c-9.39 0-17-7.61-17-17a1 1 0 011-1h3.5a1 1 0 011 1c0 1.35.26 2.67.76 3.88a1 1 0 01-.27 1.11l-2.2 2.2z"/>
              </svg>
            </a>
          </div>
        </div>
      </div>

      {/* Bottom Partner Logos */}
      <div className="flex flex-wrap justify-center gap-8 items-center border-t border-gray-600 pt-6 mt-10 opacity-80">
        {[
          "aws.png",
          "azure.png",
          "pci.png",
          "visa.png",
          "mastercard.png",
          "cloudflare.png",
          "gpay.png",
          "iso27001.png",
        ].map((logo, index) => (
          <img
            key={index}
            src={`/footer-logos/${logo}`}
            alt={`partner-${index}`}
            className="h-6 grayscale hover:grayscale-0 transition duration-300"
          />
        ))}
      </div>
    </footer>
  );
};

export default Footer;
