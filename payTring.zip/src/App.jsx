import React from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/navbar";
import Home from "./components/home";
import TopBanner from "./components/TopBanner";
import Footer from "./components/footer";

const App = () => {
  return (
    <>
      <TopBanner />
      <Navbar />
   
      <Routes>
        <Route path="/" element={<Home />} />
        {/* <Route path="/about" element={<About />} /> */}
      </Routes>
       <Footer />
    </>
  );
};

export default App;
