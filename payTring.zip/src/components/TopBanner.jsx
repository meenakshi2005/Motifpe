import React from "react";
import "../assets/css/style.css"; // Add this line to import custom CSS

const TopBanner = () => {
  return (
    <div className="bg-black h-10 flex items-center overflow-hidden whitespace-nowrap relative">
      <span className="scroll-text text-white text-sm">
        Welcome to MotifPe! Empowering smart digital transactions & seamless integration.
      </span>
    </div>
  );
};

export default TopBanner;
