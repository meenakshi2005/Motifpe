import React from "react";

const Home = () => {
  return (
    <section className="relative min-h-[90vh] px-[5%] pt-[100px] pb-[50px] bg-[#1e1f26] text-white overflow-hidden">
      {/* Optional: Add particle background script if using tsParticles or similar */}
      <div id="tsparticles" className="absolute top-0 left-0 w-full h-full z-0 opacity-30 pointer-events-none" />

      {/* Main Content */}
      <div className="relative z-10 max-w-[800px]">
        <h1 className="text-4xl sm:text-5xl font-bold leading-snug">
          Welcome to <span className="text-[#481b70]">MotifPe</span>
        </h1>
        <p className="text-lg mt-4 text-gray-300 leading-relaxed max-w-[600px]">
          A simple and elegant way to manage your payments and services.
        </p>

        {/* Call to Action Buttons */}
        <div className="mt-8 flex gap-4 flex-wrap">
          <button className="bg-[#481b70] hover:bg-[#3b145e] transition text-white px-6 py-3 rounded-md font-semibold">
            Get Started
          </button>
          <button className="border-2 border-[#481b70] text-[#481b70] hover:bg-[#481b70] hover:text-white transition px-6 py-3 rounded-md font-semibold">
            Contact
          </button>
        </div>
      </div>
    </section>
  );
};

export default Home;
